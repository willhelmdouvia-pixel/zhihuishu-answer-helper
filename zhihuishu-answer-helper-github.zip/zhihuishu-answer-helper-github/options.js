const key = document.getElementById('key'), model = document.getElementById('model'), status = document.getElementById('status');
chrome.storage.local.get(['apiKey', 'model']).then(config => { key.value = config.apiKey || ''; model.value = config.model || 'deepseek-flash'; });
document.getElementById('save').addEventListener('click', async () => {
  const apiKey = key.value.trim();
  if (!apiKey) { status.textContent = '请输入 API Key'; return; }
  try {
    await chrome.storage.local.set({ apiKey, model: model.value.trim() || 'deepseek-flash' });
    status.textContent = '配置已保存，可以关闭此页面并刷新智慧树。';
  } catch (_) { status.textContent = '保存失败，请重试。'; }
});
