(() => {
  const visible = el => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  function refresh() {
    const box = [...document.querySelectorAll('textarea')].find(e => visible(e) && (e.placeholder || '').includes('回答'));
    const existing = document.getElementById('zhs-ai-generate');
    if (!box) { existing?.remove(); return; }
    if (existing) return;
    const button = document.createElement('button');
    button.id = 'zhs-ai-generate'; button.textContent = 'AI 生成回答'; button.type = 'button';
    Object.assign(button.style, { position:'fixed', right:'35px', top:'25%', zIndex:'2147483647', padding:'10px', background:'#357bf5', color:'white', border:'0', borderRadius:'6px', cursor:'pointer' });
    document.body.appendChild(button);
    button.onclick = async () => {
      const question = [...document.querySelectorAll('p')].filter(visible).map(e => e.innerText.trim()).find(s => s.length > 8);
      try {
        const q = validateQuestion(question);
        button.disabled = true; button.textContent = '生成中…';
        const result = await chrome.runtime.sendMessage({type:'generate', question:q});
        if (result?.error) throw new Error(result.error);
        const current = [...document.querySelectorAll('textarea')].find(e => visible(e) && (e.placeholder || '').includes('回答'));
        if (!current || current !== box) throw new Error('回答框已变化，请重新操作。');
        const answer = normalizeAnswer(result?.answer);
        if (!answer) throw new Error('生成的回答为空。');
        const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value').set;
        setter.call(current, answer); current.dispatchEvent(new Event('input', {bubbles:true}));
      } catch (error) { alert(error.message || '生成失败'); }
      finally { button.disabled = false; button.textContent = 'AI 生成回答'; }
    };
  }
  new MutationObserver(refresh).observe(document.documentElement, {childList:true, subtree:true, attributes:true, attributeFilter:['style', 'class', 'hidden']});
  refresh();
  let busy = false;
  const key = 'qaAutoWalk';
  const isList = () => location.hash.includes('/web/home/');
  const isDetail = () => location.hash.includes('/web/questionDetail/');
  const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
  async function walk() {
    if (busy) return;
    busy = true;
    try {
      let state = (await chrome.storage.local.get(key))[key];
      if (!state?.active) return;
      if (searchTimedOut(state, Date.now())) { await stopWalk('寻找超时，已自动停止。'); return; }
      if (isList() && state.phase === 'seek') {
        const cards = [...document.querySelectorAll('li.question-item .question-content')].filter(visible);
        const title = nextQuestion(cards.map(x => (x.getAttribute('title') || x.innerText).trim()), state.seen);
        if (!title || state.seen.length >= 100) {
          await chrome.storage.local.set({[key]:{...state, active:false}});
          alert('当前列表中没有更多未尝试的问题。'); return;
        }
        const item = cards.find(x => (x.getAttribute('title') || x.innerText).trim() === title);
        const target = item.querySelector('span');
        if (!target) { await stopWalk('题目无法打开，寻找已停止。'); return; }
        await chrome.storage.local.set({[key]:{...state, phase:'checking', stepStarted:Date.now(), current:title, seen:[...state.seen,title]}});
        target.click();
      } else if (isDetail() && state.phase === 'checking') {
        await pause(3500);
        state = (await chrome.storage.local.get(key))[key];
        if (!state?.active || state.phase !== 'checking') return;
        const answerButton = [...document.querySelectorAll('*')].find(e => e.children.length === 0 && e.textContent.trim() === '我来回答' && visible(e));
        if (answerButton) {
          await chrome.storage.local.set({[key]:{...state, active:false, phase:'found'}});
          answerButton.click();
          refresh();
        } else {
          await chrome.storage.local.set({[key]:{...state, phase:'seek'}});
          location.assign(state.listUrl);
        }
      }
    } finally { busy = false; }
  }
  async function stopWalk(reason) {
    const state = (await chrome.storage.local.get(key))[key];
    if (!state?.active) return;
    await chrome.storage.local.set({[key]:{...state,active:false,phase:'stopped'}});
    if (reason) alert(reason);
  }
  function addWalkControls() {
    if (!isList() || document.getElementById('zhs-walk-start')) return;
    const start = document.createElement('button'); start.id = 'zhs-walk-start'; start.textContent = '寻找可回答问题';
    Object.assign(start.style, {position:'fixed',right:'25px',top:'32%',zIndex:'2147483647',padding:'10px',background:'#357bf5',color:'#fff',border:0,borderRadius:'6px',cursor:'pointer'});
    start.onclick = async () => {
      const old = (await chrome.storage.local.get(key))[key];
      await chrome.storage.local.set({[key]:{active:true,phase:'seek',startedAt:Date.now(),listUrl:location.href,seen:old?.listUrl === location.href ? old.seen || [] : []}});
      walk();
    };
    document.body.appendChild(start);
  }
  function addStopControl() {
    if (document.getElementById('zhs-walk-stop')) return;
    const stop = document.createElement('button'); stop.id = 'zhs-walk-stop'; stop.textContent = '停止寻找';
    Object.assign(stop.style, {position:'fixed',right:'25px',top:'39%',zIndex:'2147483647',padding:'10px',background:'#555',color:'#fff',border:0,borderRadius:'6px',cursor:'pointer'});
    stop.onclick = () => stopWalk('已停止寻找。');
    document.body.appendChild(stop);
  }
  addWalkControls();
  addStopControl();
  window.addEventListener('hashchange', () => { addWalkControls(); walk(); });
  setTimeout(() => { addWalkControls(); walk(); }, 1500);
  setInterval(async () => {
    const state = (await chrome.storage.local.get(key))[key];
    if (searchTimedOut(state, Date.now())) await stopWalk('寻找超时，已自动停止。请检查页面是否正常加载。');
  }, 2000);
})();
