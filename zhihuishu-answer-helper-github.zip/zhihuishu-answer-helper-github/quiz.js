(() => {
  const visible = e => !!e.getClientRects().length;
  const widget = document.createElement('div');
  Object.assign(widget.style, {position:'fixed', right:'20px', top:'24%', zIndex:'2147483647', fontFamily:'system-ui, sans-serif'});
  const icon = document.createElement('button');
  icon.type = 'button'; icon.textContent = '答'; icon.title = '展开并开始答题';
  icon.setAttribute('aria-label','展开答题助手'); icon.setAttribute('aria-expanded','false');
  Object.assign(icon.style, {width:'48px', height:'48px', border:'0', borderRadius:'50%', background:'#357bf5', color:'#fff', fontSize:'19px', fontWeight:'bold', boxShadow:'0 4px 16px #0003', cursor:'pointer'});
  const panel = document.createElement('div');
  panel.hidden = true;
  Object.assign(panel.style, {width:'240px', maxWidth:'calc(100vw - 40px)', padding:'14px', background:'#fff', color:'#222', border:'1px solid #dce3ef', borderRadius:'12px', boxShadow:'0 6px 24px #0003', fontSize:'14px', lineHeight:'1.5'});
  const title = document.createElement('strong'); title.textContent = '智慧树答题助手';
  const close = document.createElement('button'); close.type = 'button'; close.textContent = '×'; close.setAttribute('aria-label','收起答题助手');
  Object.assign(close.style, {float:'right', border:'0', background:'transparent', fontSize:'21px', lineHeight:'20px', cursor:'pointer', color:'#667085'});
  const status = document.createElement('span'); status.textContent = '点击浏览器扩展图标开始连续答题';
  Object.assign(status.style, {display:'block', margin:'12px 0', overflowWrap:'anywhere'});
  const start = document.createElement('button'); start.textContent = '开始'; start.type = 'button';
  const stop = document.createElement('button'); stop.textContent = '停止'; stop.type = 'button';
  const button = document.createElement('button'); button.type = 'button'; button.textContent = '文字解答当前题';
  const settings = document.createElement('button'); settings.textContent = 'API 设置'; settings.type = 'button';
  for (const control of [start, stop, button, settings]) Object.assign(control.style, {margin:'3px 5px 3px 0', padding:'6px 9px', border:'1px solid #d4ddec', borderRadius:'6px', background:'#f5f8ff', color:'#245bc0', cursor:'pointer'});
  settings.onclick = () => chrome.runtime.sendMessage({type:'open-options'});
  panel.append(title, close, status, start, stop, button, settings); widget.append(icon, panel); document.body.appendChild(widget);
  const setExpanded = expanded => { panel.hidden = !expanded; icon.hidden = expanded; icon.setAttribute('aria-expanded', String(expanded)); };
  close.onclick = () => setExpanded(false);
  let running = false, busy = false, answered = 0, generation = 0, hiddenCaptures = 0;
  stop.onclick = () => { running = false; generation++; button.disabled = busy; status.textContent = '已停止'; };
  const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
  function currentSubject() { const all = [...document.querySelectorAll('.examPaper_subject')].filter(visible); return all.length === 1 ? all[0] : null; }
  async function captureNext(runId) {
    if (!running || busy || generation !== runId) return;
    const subject = currentSubject();
    if (!subject) throw new Error('无法定位当前题目。');
    subject.scrollIntoView({block:'center'});
    await wait(400);
    if (!running || generation !== runId) return;
    let result;
    hiddenCaptures++; widget.style.visibility = 'hidden';
    try { await wait(100); if (!running || generation !== runId) return; result = await chrome.runtime.sendMessage({type:'quiz-capture'}); }
    finally { hiddenCaptures--; if (!hiddenCaptures) widget.style.visibility = ''; }
    if (!running || generation !== runId) { if (result) result.image = null; return; }
    if (result?.error || !result?.image) throw new Error(result?.error || '截图失败');
    await processScreenshot(result.image, runId);
    result.image = null;
  }
  const questionType = subject => detectQuestionType(subject.querySelector('.subject_type')?.innerText || '');
  async function applyAnswer(nodes, options, answer, type, mayContinue = () => true) {
    const indices = type === 'multiple' ? parseChoices(answer, options.length) : [parseChoice(answer, options.length)];
    if (type === 'multiple') {
      const changes = choiceChanges(nodes.map(selectedState), indices);
      for (const index of changes) {
        if (!mayContinue()) throw new Error('已停止，请检查当前题目。');
        const label = nodes[index].querySelector('.label');
        if (!label) throw new Error('无法操作选项，请手动选择。');
        label.click();
        await new Promise(resolve => setTimeout(resolve, 0));
        if (selectedState(nodes[index]) !== indices.includes(index)) throw new Error('无法确认选项状态，请手动核对。');
      }
    } else {
      if (!mayContinue()) throw new Error('已停止，请检查当前题目。');
      const label = nodes[indices[0]].querySelector('.label');
      if (!label) throw new Error('无法操作选项，请手动选择。');
      label.click();
      await wait(0);
      if (selectedState(nodes[indices[0]]) !== true) throw new Error('无法确认选择结果，请手动核对。');
    }
    return indices.map(i => options[i]).join('；');
  }
  async function processScreenshot(inputImage, runId) {
      busy = true;
      let image = inputImage, cropped = null, canvas = null;
      try {
        const subjects = [...document.querySelectorAll('.examPaper_subject')].filter(visible);
        if (subjects.length !== 1) throw new Error('请先打开一条选择题。');
        const subject = subjects[0];
        const type = questionType(subject);
        const identity = subject.querySelector('.subject_num')?.innerText.trim();
        const nodes = [...subject.querySelectorAll('.subject_node .nodeLab')].filter(visible);
        const options = nodes.map(n => n.querySelector('.node_detail')?.innerText.trim() || '');
        if (options.length < 2 || options.some(x => !x) || new Set(options).size !== options.length) throw new Error('选项无法完整识别。');
        const rect = subject.getBoundingClientRect();
        if (rect.top < 0 || rect.left < 0 || rect.bottom > innerHeight || rect.right > innerWidth || rect.width < 10 || rect.height < 10) throw new Error('请调整页面，让整道题和全部选项都显示在窗口内。');
        const bitmap = await createImageBitmap(await (await fetch(image)).blob());
        const sx = bitmap.width / innerWidth, sy = bitmap.height / innerHeight;
        canvas = document.createElement('canvas'); canvas.width = Math.ceil(rect.width * sx); canvas.height = Math.ceil(rect.height * sy);
        canvas.getContext('2d').drawImage(bitmap, rect.left*sx, rect.top*sy, rect.width*sx, rect.height*sy, 0, 0, canvas.width, canvas.height);
        bitmap.close(); image = null; inputImage = null;
        cropped = canvas.toDataURL('image/jpeg', 0.9);
        button.textContent = '正在识别截图…'; button.disabled = true;
        const result = await chrome.runtime.sendMessage({type:'quiz-vision',image:cropped,options,questionType:type});
        cropped = null; canvas.width = 0; canvas.height = 0; canvas = null;
        if (result?.error) throw new Error(result.error);
        if (!running) return;
        const current = [...document.querySelectorAll('.examPaper_subject')].filter(visible);
        if (current.length !== 1 || current[0] !== subject || subject.querySelector('.subject_num')?.innerText.trim() !== identity || nodes.some((n,i) => !n.isConnected || !visible(n) || n.querySelector('.node_detail')?.innerText.trim() !== options[i])) throw new Error('题目或选项已变化，请重新截图。');
        const chosen = await applyAnswer(nodes, options, result?.answer, type, () => running);
        if (!running) return;
        answered++;
        status.textContent = `已完成 ${answered} 题：${chosen}`;
        const next = [...document.querySelectorAll('button')].find(x => visible(x) && x.textContent.trim() === '下一题');
        if (!canContinueQuiz({running, answered, limit:50, nextAvailable:!!next && !next.disabled && next.getAttribute('aria-disabled') !== 'true'})) {
          running = false; status.textContent = `已完成 ${answered} 题，请检查并保存最后一题。`; return;
        }
        if (!identity) throw new Error('无法确认题号，已停止自动切题。');
        next.click();
        let changed = false;
        for (let i=0; i<20 && running; i++) { await wait(250); const current = currentSubject(); if (current && current.querySelector('.subject_num')?.innerText.trim() !== identity) { changed = true; break; } }
        if (running && !changed) throw new Error('下一题未加载，已停止。');
      } catch (error) { running = false; status.textContent = error.message || '截图识别失败，已停止。'; }
      finally { image = null; inputImage = null; cropped = null; if (canvas) {canvas.width = 0; canvas.height = 0;} busy = false; button.disabled = running; button.textContent = '文字解答当前题'; }
      if (running && generation === runId) { try { await captureNext(runId); } catch (error) { if (generation === runId) { running = false; button.disabled = false; status.textContent = error.message; } } }
  }
  function startContinuous() {
    if (!running && !busy) {
      running = true; answered = 0; button.disabled = true; status.textContent = '开始连续识别…';
      const runId = ++generation;
      captureNext(runId).catch(error => { if (generation === runId) { running = false; button.disabled = false; status.textContent = error.message || '已停止'; } });
    }
  }
  icon.onclick = () => { setExpanded(true); startContinuous(); };
  start.onclick = startContinuous;
  chrome.runtime.onMessage.addListener((msg, sender, respond) => {
    if (msg?.type !== 'quiz-start-continuous') return;
    setExpanded(true); startContinuous();
    respond({ok:true});
  });
  button.onclick = async () => {
    try {
      const subjects = [...document.querySelectorAll('.examPaper_subject')].filter(visible);
      if (subjects.length !== 1) throw new Error('无法唯一定位当前题目，请检查页面是否完全加载。');
      const subject = subjects[0];
      const type = questionType(subject);
      const nodes = [...subject.querySelectorAll('.subject_node .nodeLab')].filter(visible);
      const options = nodes.map(n => n.querySelector('.node_detail')?.innerText.trim() || '');
      if (options.length < 2 || options.some(x => !x) || new Set(options).size !== options.length) throw new Error('选项无法完整识别，请手动回答。');
      let question = subject.querySelector('.subject_describe')?.innerText.trim();
      if (!question) question = prompt('未能自动读取题干，请输入当前题目文字：');
      if (question === null) return;
      question = validateQuestion(question);
      button.disabled = true; button.textContent = '正在分析…';
      const result = await chrome.runtime.sendMessage({type:'quiz', question, options, questionType:type});
      if (result?.error) throw new Error(result.error);
      const current = [...document.querySelectorAll('.examPaper_subject')].filter(visible);
      if (current.length !== 1 || current[0] !== subject || nodes.some((n,i) => !n.isConnected || !visible(n) || n.querySelector('.node_detail')?.innerText.trim() !== options[i])) throw new Error('题目或选项已变化，请重新操作。');
      const chosen = await applyAnswer(nodes, options, result?.answer, type);
      alert(`AI 建议：${chosen}。请核对后点击“下一题”保存。`);
    } catch (error) { alert(error.message || '生成失败'); }
    finally { button.disabled = false; button.textContent = '文字解答当前题'; }
  };
})();
