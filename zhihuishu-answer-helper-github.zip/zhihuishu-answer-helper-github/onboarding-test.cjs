const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

let installed, opens = 0;
const backgroundChrome = {
  action: {onClicked: {addListener() {}}},
  runtime: {
    onMessage: {addListener() {}},
    onInstalled: {addListener(fn) {installed = fn;}},
    openOptionsPage() {opens++;}
  }
};
vm.runInNewContext(fs.readFileSync('background.js', 'utf8'), {chrome: backgroundChrome, importScripts() {}});

const elements = Object.fromEntries(['key', 'model', 'status', 'save'].map(id => [id, {
  value: '', textContent: '',
  addEventListener(type, callback) {if (type === 'click') this.onclick = callback;}
}]));
let writes = [];
const optionsChrome = {storage:{local:{
  async get() {return {};},
  async set(value) {writes.push(value);}
}}};
vm.runInNewContext(fs.readFileSync('options.js', 'utf8'), {
  chrome: optionsChrome,
  document: {getElementById(id) {return elements[id];}}
});

(async () => {
  await Promise.resolve();
  assert.equal(typeof installed, 'function', '首次安装监听器应已注册');
  installed({reason:'install'});
  assert.equal(opens, 1, '首次安装时自动打开设置');
  installed({reason:'update'});
  assert.equal(opens, 1, '更新时不重复打开设置');
  elements.key.value = '   ';
  await elements.save.onclick();
  assert.equal(writes.length, 0, '空密钥不能保存');
  assert.match(elements.status.textContent, /密钥|Key/i, '空密钥应显示提示');
  elements.key.value = 'test-key';
  elements.model.value = 'deepseek-flash';
  await elements.save.onclick();
  assert.equal(writes.length, 1, '有密钥时应保存');
  assert.equal(writes[0].apiKey, 'test-key');
  assert.equal(writes[0].model, 'deepseek-flash');
  assert.match(elements.status.textContent, /保存|成功/, '保存后应显示状态');
  console.log('onboarding OK');
})().catch(error => {console.error(error); process.exitCode = 1;});
