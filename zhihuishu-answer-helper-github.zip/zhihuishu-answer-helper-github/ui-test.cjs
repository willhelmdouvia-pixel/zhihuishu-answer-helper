const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

class Element {
  constructor(tagName) {
    this.tagName = tagName.toUpperCase();
    this.children = [];
    this.style = {};
    this.attributes = {};
    this.hidden = false;
    this.textContent = '';
  }
  appendChild(child) { this.children.push(child); child.parentNode = this; return child; }
  append(...children) { for (const child of children) this.appendChild(child); }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  addEventListener(name, handler) { this['on' + name] = handler; }
  click() { if (this.onclick) this.onclick({target:this, stopPropagation(){}}); }
  getClientRects() { return this.hidden ? [] : [{}]; }
}

let subject = null, scrollCount = 0, captureCount = 0, onMessage;
const timers = [];
const document = {
  body: new Element('body'),
  createElement: name => new Element(name),
  querySelectorAll: selector => selector === '.examPaper_subject' && subject ? [subject] : []
};
const chrome = {runtime:{onMessage:{addListener(fn){onMessage = fn;}}, sendMessage:async message => {if (message.type === 'quiz-capture') captureCount++; return {error:'测试结束'};}}};
vm.runInNewContext(fs.readFileSync('quiz.js','utf8'), {document, chrome, setTimeout: callback => timers.push(callback), clearTimeout(){}});
function all(node) { return [node, ...node.children.flatMap(all)]; }
function byLabel(label) { return all(document.body).find(element => element.getAttribute('aria-label') === label); }

(async () => {
  const icon = byLabel('展开答题助手');
  const close = byLabel('收起答题助手');
  assert.ok(icon, '页面应显示展开答题助手的图标');
  assert.ok(close, '展开面板应有收起按钮');
  const panel = close.parentNode;
  assert.equal(panel.hidden, true, '面板初始应收起');
  icon.click();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(panel.hidden, false, '点击图标后面板应展开');
  assert.ok(all(panel).some(element => element.textContent.includes('无法定位当前题目')), '点击图标应开始答题，并在没有题目时显示错误');
  close.click();
  assert.equal(panel.hidden, true, '点击收起后面板应隐藏');
  subject = {getClientRects:() => [{}], scrollIntoView:() => {scrollCount++;}};
  let reply;
  onMessage({type:'quiz-start-continuous'}, {}, value => {reply = value;});
  assert.equal(reply.ok, true, '工具栏消息应得到确认');
  assert.equal(panel.hidden, false, '工具栏启动应展开面板');
  assert.equal(scrollCount, 1, '工具栏消息启动答题');
  const start = all(panel).find(element => element.textContent === '开始');
  const stop = all(panel).find(element => element.textContent === '停止');
  assert.ok(start && stop, '面板应提供开始和停止按钮');
  start.click();
  assert.equal(scrollCount, 1, '运行时点击开始不应重复启动');
  close.click();
  onMessage({type:'quiz-start-continuous'}, {}, () => {});
  assert.equal(scrollCount, 1, '收起不应停止运行');
  stop.click();
  start.click();
  assert.equal(scrollCount, 2, '停止后应能重新开始');
  const fireTimers = async () => {for (const timer of timers.splice(0)) timer(); await new Promise(resolve => setImmediate(resolve));};
  await fireTimers();
  await fireTimers();
  assert.equal(captureCount, 1, '停止后重新开始只能发出一次截图请求');
  console.log('quiz UI OK');
})().catch(error => {console.error(error); process.exitCode = 1;});
