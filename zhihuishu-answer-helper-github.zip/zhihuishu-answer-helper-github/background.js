importScripts('rules.js');
chrome.runtime.onInstalled.addListener(details => {
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
});
chrome.action.onClicked.addListener(async tab => {
  if (!tab.url?.startsWith('https://onlineexamh5new.zhihuishu.com/') || tab.id == null) return;
  try { await chrome.tabs.sendMessage(tab.id, {type:'quiz-start-continuous'}); } catch (_) {}
});
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  const url = sender.tab?.url || '';
  if (msg?.type === 'open-options' && url.startsWith('https://onlineexamh5new.zhihuishu.com/')) { chrome.runtime.openOptionsPage(); respond({ok:true}); return; }
  if (msg?.type === 'quiz-capture' && url.startsWith('https://onlineexamh5new.zhihuishu.com/') && sender.tab?.id != null) {
    (async () => {
      let image;
      try {
        const tab = sender.tab;
        const before = await chrome.tabs.query({active:true,windowId:tab.windowId});
        if (before[0]?.id !== tab.id) throw new Error('请保持测验标签页在前台。');
        image = await chrome.tabs.captureVisibleTab(tab.windowId,{format:'jpeg',quality:90});
        const after = await chrome.tabs.query({active:true,windowId:tab.windowId});
        if (after[0]?.id !== tab.id) throw new Error('标签页已切换，已停止。');
        respond({image});
      } catch (error) { const message = error.message || '截图失败'; respond({error:/permission|access|activeTab/i.test(message) ? '请先点击浏览器工具栏中的智慧树答题助手图标，开启截图答题。' : message}); }
      finally { image = null; }
    })();
    return true;
  }
  const discussion = msg?.type === 'generate' && url.startsWith('https://qah5.zhihuishu.com/');
  const quiz = ['quiz', 'quiz-vision'].includes(msg?.type) && url.startsWith('https://onlineexamh5new.zhihuishu.com/');
  const vision = msg?.type === 'quiz-vision' && quiz;
  if (!discussion && !quiz) return;
  (async () => {
    const { apiKey, model = 'deepseek-flash' } = await chrome.storage.local.get(['apiKey', 'model']);
    if (!apiKey) throw new Error('请先在扩展详情中打开选项，设置 DeepSeek API Key。');
    if (!vision && (typeof msg.question !== 'string' || !msg.question.trim() || msg.question.length > 3000)) throw new Error('题目无效');
    if (quiz && (!Array.isArray(msg.options) || msg.options.length < 2 || msg.options.length > 10 || msg.options.some(o => typeof o !== 'string' || !o.trim() || o.length > 1000))) throw new Error('选项无效');
    if (quiz && !['single','multiple','judgment'].includes(msg.questionType)) throw new Error('不支持的题型');
    const system = quiz ? (msg.questionType === 'multiple' ? '回答多选题，只返回 JSON 对象，格式为 {"indices":[数字]}，数组包含所有正确选项的序号，序号从0开始。' : `回答${msg.questionType === 'judgment' ? '判断题' : '单选题'}，只返回 JSON 对象，格式为 {"index":数字}，index 是所选选项在给定列表中的序号，从0开始。`) : '回答课程讨论问题，用自然生活化中文写一段，不超过200字，直接回答，不要标题。';
    const input = vision ? [{type:'text',text:`请识别图片中的${msg.questionType === 'multiple' ? '多选题' : msg.questionType === 'judgment' ? '判断题' : '单选题'}并回答。选项按下列顺序排列：${JSON.stringify(msg.options)}`},{type:'image_url',image_url:{url:validateVisionData(msg.image)}}] : quiz ? JSON.stringify({question:msg.question,options:msg.options}) : msg.question;
    const response = await fetch('https://api.deepseek.com/chat/completions', {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({model:vision ? 'deepseek-flash' : model, messages: [{role:'system', content:system}, {role:'user', content:input}], max_tokens: 400, thinking: {type:'disabled'}, ...(quiz ? {response_format:{type:'json_object'}} : {})})
    });
    if (!response.ok) throw new Error(`DeepSeek 请求失败（HTTP ${response.status}），请检查密钥、余额和模型。`);
    const data = await response.json();
    const answer = data.choices?.[0]?.message?.content;
    if (!answer) throw new Error('API 未返回回答。');
    return answer;
  })().then(answer => respond({answer}), error => respond({error: error.message}));
  return true;
});
