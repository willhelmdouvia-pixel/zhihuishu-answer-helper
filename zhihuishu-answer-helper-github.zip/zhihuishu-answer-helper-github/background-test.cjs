const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');

let listener, request;
const context = {
  importScripts() {},
  validateVisionData(value) { return value; },
  chrome: {
    action: {onClicked: {addListener() {}}},
    runtime: {onMessage: {addListener(fn) {listener = fn;}}, onInstalled: {addListener() {}}},
    storage: {local: {async get() {return {apiKey:'test-key',model:'test-model'};}}},
    tabs: {async query() {return [{id:7}];}, async captureVisibleTab() {throw new Error('activeTab permission is required');}}
  },
  async fetch(_url, options) {
    request = JSON.parse(options.body);
    return {ok:true, async json() {return {choices:[{message:{content:'{"index":1}'}}]};}};
  }
};
vm.runInNewContext(fs.readFileSync('background.js','utf8'), context);
const sender = {tab:{id:7, windowId:1, url:'https://onlineexamh5new.zhihuishu.com/test'}};
async function send(message) { return await new Promise(resolve => listener(message,sender,resolve)); }
(async () => {
  for (const type of ['quiz','quiz-vision']) {
    const result = await send({type, question:'判断题干', options:['错','对'], questionType:'judgment', image:'data:image/jpeg;base64,YWJj'});
    assert.equal(result.answer, '{"index":1}');
    assert.match(request.messages[0].content, /判断题/);
    if (type === 'quiz-vision') assert.match(request.messages[1].content[0].text, /判断题/);
    else assert.deepEqual(JSON.parse(request.messages[1].content).options, ['错','对']);
  }
  const capture = await send({type:'quiz-capture'});
  assert.match(capture.error, /工具栏.*图标/);
  console.log('judgment background OK');
})().catch(error => { console.error(error); process.exitCode = 1; });
