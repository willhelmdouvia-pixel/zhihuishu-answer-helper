@echo off
start "" msedge.exe "edge://extensions/"
start "" explorer.exe "%~dp0."
start "" notepad.exe "%~dp0README.md"
